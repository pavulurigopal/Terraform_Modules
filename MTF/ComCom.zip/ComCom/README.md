# Introduction 
POC for comcom - Mastercard project. 
This repo contains terraform code to provision Azure infrastructure along with Azure DevOps pipeline script.
